package com.example.demo1.demo6;

import android.content.Context;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Demo6Function {
    //doc du lieu dang chuoi
    public void getStringVolley(Context context, TextView textView)
    {
        //B1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //B2. url
        String url = "https://www.google.com/";
        //B3. Truyen tham so
        //StringRequest(phuongThuc,Url,thanhcong,thatbai)
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //lay ve 1000 ky thu
                        textView.setText("Kq: "+response.substring(0,1000));
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //b4. thuc thi
        queue.add(stringRequest);
    }
    //doc du lieu MANG cua cac DOI TUONG
    //goi mang truoc, goi doi tuong sau
    String strJSON = "";
    public  void getJSON_Array_of_objects(Context context,TextView textView)
    {
        strJSON="";
        //b1. Tao request
        RequestQueue queue = Volley.newRequestQueue(context);
        //b2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/array_json_new.json";
        //b3. goi request (goi MANG cua DOI TUONG)
        //goi mang truoc, goi doi tuong sau
        //JsonArrayRequest(url,thanhCong,thatBai)

        JsonArrayRequest request = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //den day ta lay duoc mang
                //nhiem vu: chuyen tu mang sang doi tuong
                for(int i = 0;i<response.length();i++)//for tung doi tuong cua mang
                {
                    try{
                        JSONObject person = response.getJSONObject(i);//lay ve tung doi tuong
                        String name = person.getString("name");
                        String email = person.getString("email");
                        JSONObject phone = person.getJSONObject("phone");
                        String mobile = phone.getString("mobile");
                        String home = phone.getString("home");
                        //Chuyen ket qua doc duoc thanh chuoi
                        strJSON += "Name: "+name+"\n\n";
                        strJSON += "email: "+email+"\n\n";
                        strJSON += "mobile: "+mobile+"\n\n";
                        strJSON += "home: "+home+"\n\n";

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                textView.setText(strJSON);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //b4. thuc thi
        queue.add(request);

    }
}
