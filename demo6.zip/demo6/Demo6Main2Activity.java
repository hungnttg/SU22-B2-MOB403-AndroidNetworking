package com.example.demo1.demo6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo6Main2Activity extends AppCompatActivity {
    Button btnRead;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo6_main2);
        btnRead = findViewById(R.id.demo61BtnRead);
        tv = findViewById(R.id.demo6Tv);
        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //new Demo6Function().getStringVolley(Demo6Main2Activity.this,tv);
                new Demo6Function().getJSON_Array_of_objects(Demo6Main2Activity.this,tv);
            }
        });
    }
}
