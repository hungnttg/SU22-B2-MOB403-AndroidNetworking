package com.example.demo1.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Demo32Main2Activity extends AppCompatActivity {
    Button btn1;
    EditText txt1;
    TextView tv1;
    String path="https://batdongsanabc.000webhostapp.com/mob403/demo2_api_post.php";
    String canh_param="";
    String kq="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main2);
        btn1  =findViewById(R.id.demo32Btn1);
        txt1 = findViewById(R.id.demo32Txt1);
        tv1 = findViewById(R.id.demo32Tv1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                canh_param = txt1.getText().toString().trim();
                new Demo32AsyncTask().execute();
            }
        });
    }
    protected class Demo32AsyncTask extends AsyncTask<Void,Void,Void>{
        //ham doc du lieu tu server
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                URL url = new URL(path);
                // xu ly tham so POST
                String param = "canh="+ URLEncoder.encode(canh_param,"utf-8");
                //mo ket noi
                HttpURLConnection urlConnection
                        =(HttpURLConnection)url.openConnection();
                //thiet lap thuoc tinh cho tham so POST
                urlConnection.setDoOutput(true);
                urlConnection.setRequestMethod("POST");
                urlConnection.setFixedLengthStreamingMode(param.getBytes().length);
                urlConnection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
                //doc du lieu
                //b1. lay ve tham so
                PrintWriter printWriter =
                        new PrintWriter(urlConnection.getOutputStream());
                printWriter.print(param);
                printWriter.close();
                //b2. tien hanh doc
                String line="";
                BufferedReader br
                        =new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                while ((line=br.readLine())!=null)
                {
                    stringBuilder.append(line);
                }
                kq = stringBuilder.toString();
                urlConnection.disconnect();

            } catch (MalformedURLException | UnsupportedEncodingException e) {
                kq = e.getMessage();
                e.printStackTrace();
            } catch (IOException e) {
                kq  =e.getMessage();
                e.printStackTrace();
            }
            return null;
        }
        //ham tra ket qua cho client
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            tv1.setText(kq);
        }
    }
}
