package com.example.demo1.demo1;

import android.graphics.Bitmap;

public interface Demo21Interface {
    void loadAnh(Bitmap bitmap);
    void loi();
}
