package com.example.demo1.demo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo31Main2Activity extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    TextView tv1;
    String path = "https://batdongsanabc.000webhostapp.com/mob403/demo2_api_get.php";
    String name="";
    String mark="";
    String kq="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main2);
        tv1 = findViewById(R.id.demo31Tv1);
        txt1 = findViewById(R.id.demo31Txt1);
        txt2 = findViewById(R.id.demo31Txt2);
        btn1 = findViewById(R.id.demo31Btn1);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name=txt1.getText().toString();
                mark=txt2.getText().toString();
                new Demo31AsyncTask().execute();//thuc thi 2 ham doInBackground va onPostExecute
            }
        });
    }
    public class Demo31AsyncTask extends AsyncTask<Void,Void,Void>{
        //Ham xu ly du lieu phia server
        @Override
        protected Void doInBackground(Void... voids) {
            path+="?name="+name+"&mark="+mark;
            StringBuilder stringBuilder  =new StringBuilder();//bo chua du lieu
            try {
                URL url = new URL(path);//duong dan
                //moi ket noi
                BufferedReader br=
                        new BufferedReader(new InputStreamReader(
                                url.openConnection().getInputStream()));
                //doc du lieu
                String line="";//dong chua du lieu doc duoc
                while ((line = br.readLine())!=null)
                {
                    stringBuilder.append(line);//dua line vao StringBuilder
                }
                kq = stringBuilder.toString();
            } catch (MalformedURLException e) {
                kq = e.getMessage();
                e.printStackTrace();
            } catch (IOException e) {
                kq = e.getMessage();
                e.printStackTrace();
            }
            return null;
        }
        //ham tra ket qua ve cho client
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            tv1.setText(kq);
        }
    }
}
