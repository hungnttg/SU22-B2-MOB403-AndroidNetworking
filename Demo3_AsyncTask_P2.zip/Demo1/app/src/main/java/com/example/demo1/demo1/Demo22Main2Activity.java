package com.example.demo1.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo22Main2Activity extends AppCompatActivity {
    Button button;
    ImageView imageView;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo22_main2);
        button = findViewById(R.id.demo22Btn1);
        imageView  =findViewById(R.id.demo22Img1);
        textView = findViewById(R.id.demo22Tv1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Demo22AsyncTask().execute("http://tinypic.com/images/goodbye.jpg");
            }
        });
    }
    public class Demo22AsyncTask extends AsyncTask<String,Void, Bitmap>{

        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                return BitmapFactory.decodeStream(new URL(strings[0])
                        .openConnection().getInputStream());
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(bitmap!=null)
            {
                imageView.setImageBitmap(bitmap);
            }
            else
            {
                textView.setText("Loi doc du lieu");
            }
        }
    }
}
