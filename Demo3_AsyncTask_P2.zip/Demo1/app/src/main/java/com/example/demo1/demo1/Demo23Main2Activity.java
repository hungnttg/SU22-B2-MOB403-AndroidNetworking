package com.example.demo1.demo1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.demo1.R;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class Demo23Main2Activity extends AppCompatActivity {
    Button button;
    ImageView imageView;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo23_main2);
        button = findViewById(R.id.demo23Btn1);
        imageView  =findViewById(R.id.demo23Img1);
        textView = findViewById(R.id.demo23Tv1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Thread myThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final Bitmap bitmap = loadAnh("http://tinypic.com/images/goodbye.jpg");
                        imageView.post(new Runnable() {
                            @Override
                            public void run() {
                                imageView.setImageBitmap(bitmap);
                                textView.setText("Post anh thanh cong");
                            }
                        });
                    }
                });
                myThread.start();
            }
        });
    }
    private Bitmap loadAnh(String str)
    {
        try{
            return BitmapFactory.decodeStream(new URL(str).openConnection().getInputStream());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
