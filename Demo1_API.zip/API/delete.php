<?php
//khai báo biến
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$db="id10840443_springbootdb";
//tạo kết nối
$con = new mysqli($sv,$u,$p,$db);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
$sql = "DELETE FROM MyGuests WHERE id=108";
if($con->query($sql)===TRUE)
{
    echo "da xoa 1 ban ghi";
}
else
{
    echo "Loi: ".$con->error;
}
$con->close();
?>