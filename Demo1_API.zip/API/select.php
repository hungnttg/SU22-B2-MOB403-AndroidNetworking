<?php
//khai báo biến
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$db="id10840443_springbootdb";
//tạo kết nối
$con = new mysqli($sv,$u,$p,$db);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
$sql = "SELECT * FROM MyGuests";
$result = $con->query($sql);//doc du lieu tu csdl
if($result->num_rows >0)//neu so dong >0
{
    while($row = $result->fetch_assoc())//doc tung dong
    {
        echo "id: "+$row["id"]." - FirstName: ".$row["firstname"]."<br>";
    }
}
else
{
    echo "Khong co du lieu";
}
$con->close();
?>