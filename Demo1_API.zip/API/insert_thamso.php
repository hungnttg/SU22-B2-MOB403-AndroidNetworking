<?php
//khai báo biến
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$db="id10840443_springbootdb";
//tạo kết nối
$con = new mysqli($sv,$u,$p,$db);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
//truyen du lieu vao API
if(isset($_GET['firstname'])&&isset($_GET['lastname'])&&isset($_GET['email']))
{
    $first=$_GET['firstname'];//bien first nhan GET['firstname'] lam gia tri
    $last=$_GET['lastname'];
    $e = $_GET['email'];
    $sql = "INSERT INTO MyGuests(firstname,lastname,email)
    VALUES ('$first','$last','$e')";
    if($con->query($sql)===TRUE)
    {
        echo "ban ghi moi da duoc them";
    }
    else
    {
        echo "Loi: ".$con->error;
    }
}

$con->close();
//cu phap goi:
///insert_thamso.php?firstname=aaa&lastname=bbb&email=ccc
?>