<?php
//khai báo biến
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$db="id10840443_springbootdb";
//tạo kết nối
$con = new mysqli($sv,$u,$p,$db);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
$sql = "INSERT INTO MyGuests(firstname,lastname,email)
VALUES ('dulieu1','dulieu2','dulieu3')";
if($con->query($sql)===TRUE)
{
    echo "ban ghi moi da duoc them";
}
else
{
    echo "Loi: ".$con->error;
}
$con->close();
?>