<?php
//Thông tin user
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//Tạo đối tượng kết nối csdl
$con = new mysqli($sv,$u,$p,$dbname);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
//Lay tham so
//API.php?thamso1=giatri1&thamso2=giatri2
//api.php?firstname=gt1&lastname=gt2&email=gt3
if(isset($_GET['firstname'])
&&isset($_GET['id'])
&&isset($_GET['lastname'])
&&isset($_GET['email']))
{
    $i = $_GET['id'];
    $f = $_GET['firstname'];//lay gia tri cua tham so
    $l = $_GET['lastname'];
    $e = $_GET['email'];
    //Lenh insert
    $sql = "UPDATE MyGuests SET firstname='$f', lastname='$l', email='$e'
    WHERE id=".$i;
    //thuc thi
    if($con->query($sql)==TRUE)
    {
        echo "update thanh cong";
    }
    else
    {
        echo "Loi: ".$con->error;
    }
}

//dong ket noi
$con->close();
?>