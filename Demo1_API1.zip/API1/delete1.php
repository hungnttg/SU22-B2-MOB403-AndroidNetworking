<?php
//Thông tin user
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//Tạo đối tượng kết nối csdl
$con = new mysqli($sv,$u,$p,$dbname);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
//Lay tham so
//API.php?thamso1=giatri1&thamso2=giatri2
//api.php?firstname=gt1&lastname=gt2&email=gt3
if(isset($_GET['id']))
{
    $i = $_GET['id'];
    //Lenh insert
    $sql = "DELETE from MyGuests
    WHERE id=".$i;
    //thuc thi
    if($con->query($sql)==TRUE)
    {
        echo "delete thanh cong";
    }
    else
    {
        echo "Loi: ".$con->error;
    }
}

//dong ket noi
$con->close();
?>