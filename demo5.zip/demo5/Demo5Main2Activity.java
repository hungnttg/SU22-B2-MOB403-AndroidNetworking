package com.example.demo1.demo5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;
import com.example.demo1.demo5.delete.InterfaceDelete;
import com.example.demo1.demo5.delete.PrdDelete;
import com.example.demo1.demo5.delete.ServerResponseDelete;
import com.example.demo1.demo5.update.InterfaceUpdate;
import com.example.demo1.demo5.update.PrdUpdate;
import com.example.demo1.demo5.update.ServerResponseUpdate;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Demo5Main2Activity extends AppCompatActivity {
    EditText txtID,txtName,txtPrice,txtDes;
    Button btnDel,btnUpdate;
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo5_main2);
        txtID = findViewById(R.id.demo51TxtId);
        txtName = findViewById(R.id.demo51TxtName);
        txtPrice  =findViewById(R.id.demo51TxtPrice);
        txtDes = findViewById(R.id.demo51TxtDes);
        btnDel = findViewById(R.id.demo51BtnDel);
        btnUpdate = findViewById(R.id.demo51BtnUpdate);
        tvKQ = findViewById(R.id.demo51TvKQ);

    }


    public void deleteRetro1(View view) {
        //B1 - Dua du lieu vao doi tuong
        PrdDelete p = new PrdDelete();
        p.setPid(txtID.getText().toString());
        //B2 - Tao doi tuong retrofilt
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //B3. Chuan bi ham
        InterfaceDelete interfaceDelete = retrofit.create(InterfaceDelete.class);
        Call<ServerResponseDelete> call = interfaceDelete.deletePrd(p.getPid());
        //B4. thuc thi ham
        call.enqueue(new Callback<ServerResponseDelete>() {
            //neu thanh cong
            @Override
            public void onResponse(Call<ServerResponseDelete> call,
                                   Response<ServerResponseDelete> response) {
                ServerResponseDelete svr = response.body();
                tvKQ.setText(svr.getMessage());
            }
            //neu that bao
            @Override
            public void onFailure(Call<ServerResponseDelete> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }

    public void updateRetro1(View view) {
        //B1 - Dua du lieu vao doi tuong
        PrdUpdate p = new PrdUpdate();
        p.setPid(txtID.getText().toString());
        p.setName(txtName.getText().toString());
        p.setPrice(txtPrice.getText().toString());
        p.setDescription(txtDes.getText().toString());
        //B2 - Tao doi tuong retrofilt
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //B2.1 Dua du lieu vao request
        //B3. Chuan bi ham
        InterfaceUpdate interfaceUpdate = retrofit.create(InterfaceUpdate.class);
        Call<ServerResponseUpdate> call = interfaceUpdate.updateRetro(p.getPid(),
                p.getName(),p.getPrice(),p.getDescription());
        //B4. thuc thi ham
        call.enqueue(new Callback<ServerResponseUpdate>() {
            //neu thanh cong
            @Override
            public void onResponse(Call<ServerResponseUpdate> call,
                                   Response<ServerResponseUpdate> response) {
                ServerResponseUpdate svr = response.body();
                tvKQ.setText(svr.getMessage());
            }
            //neu that bao
            @Override
            public void onFailure(Call<ServerResponseUpdate> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
}
