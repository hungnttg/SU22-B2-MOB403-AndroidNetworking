package com.example.demo1.demo5.delete;

public class ServerResponseDelete {//GET
    private PrdDelete products;
    private String message;

    public PrdDelete getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
