package com.example.demo1.demo5.delete;

public class PrdDelete {
    private String pid;

    public PrdDelete(String pid) {
        this.pid = pid;
    }

    public PrdDelete() {
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
