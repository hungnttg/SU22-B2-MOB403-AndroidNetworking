package com.example.demo1.demo5.update;

public class ServerResponseUpdate {//GET
    private PrdUpdate products;
    private String message;

    public PrdUpdate getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
