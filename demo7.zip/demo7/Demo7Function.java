package com.example.demo1.demo7;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class Demo7Function {
    public void insert_volley_POST(Context context, TextView tvKQ,
                                   EditText txtName, EditText txtPrice, EditText txtDes)
    {
        //b1. Tao request
        RequestQueue queue  = Volley.newRequestQueue(context);
        //b2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/create_product.php";
        //b3. truyen tham so
        //stringRequest(method,url,ThanhCOng,ThatBai)
       StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
           @Override
           public void onResponse(String response) {
               tvKQ.setText(response.toString());
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
               tvKQ.setText(error.getMessage());
           }
       })
       {
           //truyen tham so
           @Override
           protected Map<String, String> getParams() throws AuthFailureError {
               Map<String,String> myData = new HashMap<>();
               myData.put("name",txtName.getText().toString());
               myData.put("price",txtPrice.getText().toString());
               myData.put("description",txtDes.getText().toString());
               return myData;
           }
       };
       //b4. xu ly
        queue.add(stringRequest);
    }
    //---
    public void update_volley_POST(Context context, TextView tvKQ,
                                  EditText txtPid, EditText txtName, EditText txtPrice, EditText txtDes)
    {
        //b1. Tao request
        RequestQueue queue  = Volley.newRequestQueue(context);
        //b2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/update_product.php";
        //b3. truyen tham so
        //stringRequest(method,url,ThanhCOng,ThatBai)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                tvKQ.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKQ.setText(error.getMessage());
            }
        })
        {
            //truyen tham so
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> myData = new HashMap<>();
                myData.put("pid",txtPid.getText().toString());
                myData.put("name",txtName.getText().toString());
                myData.put("price",txtPrice.getText().toString());
                myData.put("description",txtDes.getText().toString());
                return myData;
            }
        };
        //b4. xu ly
        queue.add(stringRequest);
    }
    //---
    public void delete_volley_POST(Context context, TextView tvKQ,
                                   EditText txtPid)
    {
        //b1. Tao request
        RequestQueue queue  = Volley.newRequestQueue(context);
        //b2. url
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab5/delete_product.php";
        //b3. truyen tham so
        //stringRequest(method,url,ThanhCOng,ThatBai)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                tvKQ.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tvKQ.setText(error.getMessage());
            }
        })
        {
            //truyen tham so
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> myData = new HashMap<>();
                myData.put("pid",txtPid.getText().toString());
                return myData;
            }
        };
        //b4. xu ly
        queue.add(stringRequest);
    }
}
