package com.example.demo1.demo7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;

public class Demo7Main2Activity extends AppCompatActivity {
    TextView tvKQ;
    EditText txtPid,txtName,txtPrice,txtDes;
    Context context = this;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo7_main2);
        tvKQ = findViewById(R.id.demo7TvKQ);
        txtPid = findViewById(R.id.demo7txtPid);
        txtName = findViewById(R.id.demo7txtName);
        txtPrice = findViewById(R.id.demo7txtPrice);
        txtDes = findViewById(R.id.demo7txtDes);
    }

    public void xoaVolley1(View view) {
        new Demo7Function().delete_volley_POST(context,tvKQ,txtPid);
    }

    public void suaVolley1(View view) {
        new Demo7Function().update_volley_POST(context,tvKQ,txtPid,txtName,txtPrice,txtDes);
    }

    public void themVoley1(View view) {
        new Demo7Function().insert_volley_POST(context,tvKQ,txtName,txtPrice,txtDes);
    }
}
