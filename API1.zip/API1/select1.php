<?php
//Thông tin user
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//Tạo đối tượng kết nối csdl
$con = new mysqli($sv,$u,$p,$dbname);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
$sql = "SELECT * FROM MyGuests";
//thuc thi
$result=$con->query($sql);//tra ket qua ve result
if($result->num_rows >0)//neu co du lieu
{
    while($row=$result->fetch_assoc())//doc tung ban ghi
    {
        echo "id: ".$row["id"]." - Name: ".$row["firstname"]." "
        .$row["lastname"]."<br>";
    }
}
else
{
    echo "Khong co du lieu ";
}
//dong ket noi
$con->close();
?>