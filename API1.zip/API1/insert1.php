<?php
//Thông tin user
$sv = "localhost";
$u="id10840443_user";
$p="12345678Aa@123";
$dbname="id10840443_springbootdb";
//Tạo đối tượng kết nối csdl
$con = new mysqli($sv,$u,$p,$dbname);
//kiem tra ket noi
if($con->connect_error)
{
    die("Loi ket noi: ".$con->connect_error);
}
//Lenh insert
$sql = "INSERT INTO MyGuests (firstname,lastname,email)
VALUES ('firstname1','lastname1','email1')";
//thuc thi
if($con->query($sql)==TRUE)
{
    echo "insert thanh cong";
}
else
{
    echo "Loi: ".$con->error;
}
//dong ket noi
$con->close();
?>