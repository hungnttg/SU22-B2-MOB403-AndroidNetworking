package com.example.demo1.demo4.select;

import retrofit2.Call;
import retrofit2.http.GET;

public interface InterfaceSelectProd {
    @GET("get_all_product.php")
    Call<SvrResponseSelectProd> getProd();
}
