package com.example.demo1.demo4.select;

public class SvrResponseSelectProd {
    private Prod[] products;//get
    private String message;

    public Prod[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
