package com.example.demo1.demo4.insert;

public class ServerResponsePrd {//get
    private Prd products;
    private String message;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }
}
