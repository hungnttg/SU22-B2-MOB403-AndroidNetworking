package com.example.demo1.demo4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.demo1.R;
import com.example.demo1.demo4.insert.InterfaceInsertPrd;
import com.example.demo1.demo4.insert.Prd;
import com.example.demo1.demo4.insert.ServerResponsePrd;
import com.example.demo1.demo4.select.InterfaceSelectProd;
import com.example.demo1.demo4.select.Prod;
import com.example.demo1.demo4.select.SvrResponseSelectProd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Demo41Main2Activity extends AppCompatActivity {
    EditText txtId,txtName,txtPrice,txtDes;
    Button btnInsert, btnSelect;
    TextView tvKQ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main2);
        txtId = findViewById(R.id.demo41TxtId);
        txtName = findViewById(R.id.demo41TxtName);
        txtPrice = findViewById(R.id.demo41TxtPrice);
        txtDes  = findViewById(R.id.demo41TxtDes);
        tvKQ = findViewById(R.id.demo41TvKQ);
        btnInsert = findViewById(R.id.demo41Insert);
        btnSelect = findViewById(R.id.demo41Select);
    }

    public void insertData1(View view) {
        //b1 - Tao doi tuong chua du lieu và đưa dữ liệu vào đối tượng
        Prd prd = new Prd();
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //b2. tao doi tuong retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //b3: goi ham insert
        InterfaceInsertPrd insertPrdObj = retrofit.create(InterfaceInsertPrd.class);
        //B3.1.chuan bi
        Call<ServerResponsePrd> call
                =insertPrdObj.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //b3.1. thuc thi ham
        call.enqueue(new Callback<ServerResponsePrd>() {
            //neu thanhcong
            @Override
            public void onResponse(Call<ServerResponsePrd> call, Response<ServerResponsePrd> response) {
                ServerResponsePrd serverResponsePrd = response.body();//lay ve du lieu
                tvKQ.setText(serverResponsePrd.getMessage());//dua ra thong bao
            }
            //neu that bai
            @Override
            public void onFailure(Call<ServerResponsePrd> call, Throwable t) {
                tvKQ.setText(t.getMessage());//thong bao that bai
            }
        });
    }
    String strKQ = "";
    public void selectData1(View view) {
        strKQ = "";
        //1. Tao doi tuong Retrofiy
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. goi ham select trong interface
        //2.1 tao doi tuong
        InterfaceSelectProd interfaceSelectProd = retrofit.create(InterfaceSelectProd.class);
        //2.2 chuan bi ham
        Call<SvrResponseSelectProd> call = interfaceSelectProd.getProd();
        //2.3. thuc thi lenh
        call.enqueue(new Callback<SvrResponseSelectProd>() {
            @Override
            public void onResponse(Call<SvrResponseSelectProd> call, Response<SvrResponseSelectProd> response) {
                SvrResponseSelectProd svrResponseSelectProd = response.body();//lay ket qua tra ve
                //chuyen ket qua sang list
                List<Prod> ls = new ArrayList<>(Arrays.asList(svrResponseSelectProd.getProducts()));
                //dua vao vong for de doc
                for(Prod p: ls)
                {
                    strKQ +="Name: "+p.getName()+"; Price: "+p.getPrice()+
                            "; Des: "+p.getDescription()+"\n\n";
                }
                //dua ket qua len text
                tvKQ.setText(strKQ);
            }

            @Override
            public void onFailure(Call<SvrResponseSelectProd> call, Throwable t) {
                tvKQ.setText(t.getMessage());
            }
        });
    }
}
